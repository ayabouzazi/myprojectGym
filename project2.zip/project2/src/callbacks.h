#include <gtk/gtk.h>



void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkWidget       *object_graphique,
                                        gpointer         user_data);



void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button1A_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button32_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button33_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
