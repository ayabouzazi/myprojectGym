#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "greeting.h"

void ajouter(char Login[],char password[],int role)
{
	FILE *f;
	f=fopen("/home/aya/Projects/project2/src/users.txt","a+");
	if(f!=NULL){
		fprintf(f,"%s %s %d\n", Login, password, role);
	}
	fclose(f);
}

void afficher()
{
	FILE *f;
	f=fopen("/home/aya/Projects/project2/src/users.txt","r");
	char Login[20],password[20];
	int role;
	while(fscanf(f,"%s %s %d", Login, password,&role)!=EOF){
		printf("%s %s %d\n",Login, password,role);
	}
	fclose(f);
}
void afficher1(GtkWidget *plistview)
{
enum {  COL_NOM,
	COL_PRENOM,
	COL_AGE,
	COL_SEXE,
	COL_PASSWORD,
	COL_CIN,
	COL_JOUR,
	COL_MOIS,
	COL_ANNEE,
	
	NUM_COLS};
char nom[20],prenom[20],password[20],sexe[20],cin[9],age[20];
int jour,mois,annee;
GtkListStore *liststore;
GtkTreeIter iter;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore=NULL;

FILE *f;
liststore=gtk_tree_view_get_model(plistview);
if (liststore==NULL)
{	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("nom",celrender,"text",COL_NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("prenom",celrender,"text",COL_PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("age",celrender,"text",COL_AGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("sexe",celrender,"text",COL_SEXE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("password",celrender,"text",COL_PASSWORD,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("cin",celrender,"text",COL_CIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


}
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
f=fopen("/home/aya/Projects/project2/src/aderent.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %s %s %d %d %d",nom,prenom,age,sexe,password,cin,&jour,&mois,&annee)!=EOF)
			{
			 gtk_list_store_append(liststore, &iter);
			 gtk_list_store_set(liststore,&iter,
			 COL_NOM,nom,
			 COL_PRENOM,prenom,
			 COL_AGE,age,
			 COL_SEXE,sexe,
			 COL_PASSWORD,password,
			 COL_CIN,cin,
			 COL_JOUR,jour,
			 COL_MOIS,mois,
			 COL_ANNEE,annee,
			 -1);}
fclose(f);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));
g_object_unref(liststore);
}

}

void ajouter1 (admin s)
{
FILE*f;
f=fopen("/home/aya/Projects/project2/src/aderent.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %d %d %d\n"
,s.nom,s.prenom,s.age,s.sexe,s.password,s.cin,s.dt_ab.jours,s.dt_ab.mois,s.dt_ab.annee);
fclose(f);
}
}
int verifier(char Login[20],char password[20])
{
	FILE *f;
	int role;
	int r=-1;
	char Login1[20],password1[20];
	f=fopen("/home/aya/Projects/project2/src/users.txt","r");
	
	while (fscanf(f,"%s %s %d\n",Login1,password1,&role)!=EOF){
		if (strcmp(Login1,Login)==0 && strcmp(password1,password)==0)
		{
			
			r=role;
		}
	}
	fclose(f);
	return r;
}
void modifier(admin s)
{     
    admin p;
    FILE *f , *f1;
    f=fopen("/home/aya/Projects/project2/src/aderent.txt","a+");
    f1=fopen("/home/aya/Projects/project2/src/aderent1.txt","a+");
    if (f!=NULL)
    {
while(fscanf(f,"%s %s %s %s %s %s %d %d %d\n"
,p.nom,p.prenom,p.age,p.sexe,p.password,p.cin,&p.dt_ab.jours,&p.dt_ab.mois,&p.dt_ab.annee)!=EOF){
        if(!strcmp(p.cin,s.cin))
{fprintf(f1,"%s %s %s %s %s %d %d %d\n",s.nom,s.prenom,s.age,s.sexe,s.password,s.cin,s.dt_ab.jours,s.dt_ab.mois,s.dt_ab.annee);}
	else
	fprintf(f1,"%s %s %s %s %s %s %d %d %d\n",p.nom,p.prenom,p.age,p.sexe,p.password,p.cin,p.dt_ab.jours,p.dt_ab.mois,p.dt_ab.annee);
}
fclose(f);
fclose(f1);
remove("/home/aya/Projects/project2/src/aderent.txt");
rename("/home/aya/Projects/project2/src/aderent1.txt","/home/aya/Projects/project2/src/aderent.txt");
}  
}                


void supprimer(char cin[],int n)
{
admin s;
FILE*f;
FILE*f1;
f=fopen("/home/aya/Projects/project2/src/aderent.txt","a+");
f1=fopen("/home/aya/Projects/project2/src/aderent1.txt","a+");
if (f!=NULL)
{while (fscanf(f,"%s %s %s %s %s %s %d %d %d\n",s.nom,s.prenom,s.age,s.sexe,s.password,s.cin,&s.dt_ab.jours,&s.dt_ab.mois,&s.dt_ab.annee)!=EOF)
{if (strcmp(cin,s.cin)!=0)
{
fprintf(f1,"%s %s %s %s %s %s %d %d %d\n",s.nom,s.prenom,s.age,s.sexe,s.password,s.cin,s.dt_ab.jours,s.dt_ab.mois,s.dt_ab.annee);
}
}
}
fclose(f);
fclose(f1);
remove("/home/aya/Projects/project2/src/aderent.txt");
rename("/home/aya/Projects/project2/src/aderent1.txt","/home/aya/Projects/project2/src/aderent.txt");
}




