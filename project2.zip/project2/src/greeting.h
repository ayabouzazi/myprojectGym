void ajouter(char Login[],char password[],int role);
void afficher();
void afficher1(GtkWidget *plistview);
int  verifier(char Login[],char password[]);

typedef struct
{
int jours;
int mois;
int annee;
}Date;
typedef struct
{
char nom[20];
char prenom[20];
char cin[9];
char password[20];
char sexe[20];
char age[20];
Date dt_ab;
}admin;
void ajouter1(admin s);
void modifier(admin s);
void supprimer(char cin[],int n);
